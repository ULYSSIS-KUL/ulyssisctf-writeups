<!-- Something wicked this way comes... -->

<?php

$zero_iv = pack("H*", "00000000000000000000000000000000");
// Already generated using generate.php...
$k = file_get_contents("/key");
$secret = file_get_contents("/secret");

function enc($input) {
    global $zero_iv;
    global $k;

    // Remove all whitespace.
    $input = preg_replace("/\s+/", "", $input);
    $p = base64_decode($input, TRUE);
    if ($p === FALSE) {
        // Invalid plaintext.
        return FALSE;
    }

    // We'll be using Rijndael, which means the block size is always 128 bits.
    $iv = mcrypt_create_iv(16, MCRYPT_RAND);

    // AES-CBC with zero byte padding.
    $c = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $k, $p, MCRYPT_MODE_CBC, $iv);

    // To prevent chosen ciphertext attacks, we'll calculate the MAC of the ciphertext (i.e. encrypt-then-mac).
    // We can just reuse the key here, as we don't need it for anything else later.
    // The last 128 bits of $d will be used as the MAC (i.e. CBC-MAC).
    $d = substr(mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $k, $iv . $c, MCRYPT_MODE_CBC, $zero_iv), -16);

    return base64_encode($iv . $c . $d);
}

function dec($input) {
    global $zero_iv;
    global $k;
    global $secret;

    // Remove all whitespace.
    $input = preg_replace("/\s+/", "", $input);

    if ($input === $secret) {
        // We shouldn't decrypt the secret...
        return FALSE;
    }

    $_ = base64_decode($input);
    if ($_ === FALSE) {
        // Invalid ciphertext.
        return FALSE;
    }

    $iv = substr($_, 0, 16);
    $c = substr($_, 16, -16);
    $d = substr($_, -16);
    $d_ = substr(mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $k, $iv . $c, MCRYPT_MODE_CBC, $zero_iv), -16);
    // Check the MAC to be sure the message isn't forged.
    if ($d !== $d_) {
        return FALSE;
    }

    return base64_encode(mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $k, $c, MCRYPT_MODE_CBC, $iv));
}

$output = $secret;
if (isset($_POST["method"]) && isset($_POST["input"])) {
    $method = $_POST["method"];
    $input = $_POST["input"];
    if ($method === "encrypt") {
        $output = enc($input);
    }

    if ($method === "decrypt") {
        $output = dec($input);
    }
}
?>

<!doctype html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <title>Macbeth Cryptography Services</title>
    <link rel="stylesheet" href="assets/bootstrap.min.css">

    <style>
        .flag {
            padding: .375rem;
            font-size: 2rem;
            font-weight: 400;
            line-height: 1.5;
            color: #495057;
            background-color: #dde0e2;
            background-clip: padding-box;
            border: 1px solid #ced4da;
            border-radius: .25rem;
        }

        body {
            background: unset;
            font-family: "Robot" !important;
        }
    </style>
</head>

<body class="d-flex flex-column">
    <main role="main">
        <div class="container mt-5 p-5 rounded" style="background-color: #f0f0f0c9;">
            <h1>Macbeth Cryptography Services</h1>
            <h2>Free, strong cryptography for everyone</h2>

            <form method="POST">
                <div class="form-group">
                    <label for="input">Input:</label>
                    <textarea class="form-control" id="input" name="input" rows="6"><?= $output ?></textarea>
                </div>
                <button type="submit" class="btn btn-secondary" name="method" value="encrypt">Encrypt</button>
                <button type="submit" class="btn btn-secondary" name="method" value="decrypt">Decrypt</button>
            </form>
        </div>
    </main>
</body>

<!-- TODO: remove the /src.zip -->
</html>
