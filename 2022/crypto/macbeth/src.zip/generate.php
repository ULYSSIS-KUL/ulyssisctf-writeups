<?php

$k = mcrypt_create_iv(32, MCRYPT_RAND);
fwrite(fopen("/key", "w"), $k);
$iv = mcrypt_create_iv(16, MCRYPT_RAND);
$c = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $k, "FLG{" . $argv[1] . "}", MCRYPT_MODE_CBC, $iv);
$d = substr(mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $k, $iv . $c, MCRYPT_MODE_CBC, pack("H*", "00000000000000000000000000000000")), -16);
fwrite(fopen("/secret", "w"), base64_encode($iv . $c . $d));
